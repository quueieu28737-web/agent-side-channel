# Paper bundle

This bundle contains the reviewed manuscript and supplement PDFs, their source closure, and generated bibliographies. It does not include raw traces, credentials, third-party papers, or the historical experiment archive. The original E4 recovery is post hoc; its original unknown capture remains unknown. The original R44 results concern task utility in a selected sandbox cohort. The later local R44 run was stopped before completion and is not reported as a completed experiment. No independent analyst study is claimed.

The paper's raw-versus-batching comparisons are descriptive point estimates from a bounded synthetic TLS replay; they do not establish a general privacy improvement. Some reference metadata and version identities remain unresolved as disclosed in the supplement. The source requires IEEEtran and standard LaTeX packages; the included placeins.sty declares itself public domain.
